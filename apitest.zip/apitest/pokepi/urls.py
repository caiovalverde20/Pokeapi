from django.urls import path
from django.views.generic import TemplateView
from django.conf.urls import url
from .views import HomeView


urlpatterns= [
    path('', HomeView.as_view())
]
