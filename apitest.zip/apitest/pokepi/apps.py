from django.apps import AppConfig


class PokepiConfig(AppConfig):
    name = 'pokepi'
