from django.test import TestCase

# Create your tests here.
import requests
import json


baseurl = 'http://pokeapi.co'


def query_pokemon(resource_url):
    url = '{0}{1}'.format(baseurl, resource_url)
    response = requests.get(url)

    if response.status_code == 200:
        return json.loads(response.text)

#{{ form }}
#def search_poke ():
#    pokemon = input()
#    result = query('/api/v1/pokemon/{}'.format(pokemon))
#    print (result)


#search_poke()
