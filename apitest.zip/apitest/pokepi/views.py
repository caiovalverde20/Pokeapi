from django.shortcuts import render, redirect
from .forms import HomeForm
from django.views.generic import TemplateView
from .models import Post
from .tests import query_pokemon

class HomeView(TemplateView):
    template_name = 'home.html'
    baseurl = 'http://pokeapi.co'

    def get(self, request):
        form = HomeForm()
        return render(request, self.template_name, {'form': form})


    def post(self, request):
        form = HomeForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data['post']
            pokeinfo = query_pokemon('/api/v1/pokemon/{}'.format(text))
            pokespecies = query_pokemon('/api/v2/pokemon-species/{}'.format(text))
            pokename = pokeinfo['name']
            pokeid = pokeinfo ['id']
            pokedescript = pokespecies ['flavor_text_entries'] [1] ['flavor_text']
            poketype= pokeinfo['types'] [0] ['type'] ['name']
            try:
                poketype2 = pokeinfo['types'][1]['type']['name']
            except IndexError:
                poketype2 = ""


        args = {'form': form,
                'text' : text,
                'pokename': pokename,
                'pokeid': pokeid,
                'pokedescript': pokedescript,
                'poketype' : poketype,
                'poketype2' : poketype2
                }
        return render(request, self.template_name, args)